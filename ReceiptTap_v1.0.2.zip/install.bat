@echo off
echo ================================
echo   ReceiptTap 설치
echo ================================
echo.

:: 관리자 권한 확인
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo 관리자 권한이 필요합니다.
    echo 이 파일을 우클릭하고 "관리자 권한으로 실행"을 선택하세요.
    pause
    exit /b 1
)

echo SPMC 등록 중...
regsvr32 /s "%~dp0hhdspmc.dll"
if %errorLevel% equ 0 (
    echo SPMC 등록 완료!
) else (
    echo SPMC 등록 실패. 계속 진행합니다...
)

echo.
echo 설치가 완료되었습니다!
echo ReceiptTap.exe를 실행하세요.
echo.
pause
