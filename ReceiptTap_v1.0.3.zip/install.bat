@echo off
echo ================================
echo   ReceiptTap Install
echo ================================
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Run as Administrator!
    pause
    exit /b 1
)

echo [1/2] Installing SPMC driver...
if exist "%~dp0drivers\hhdspmc.inf" (
    pnputil /add-driver "%~dp0drivers\hhdspmc.inf" /install
)

echo [2/2] Registering SPMC COM...
if exist "%~dp0hhdspmc.dll" (
    regsvr32 /s "%~dp0hhdspmc.dll"
)

echo.
echo Done! Run ReceiptTap.exe
pause